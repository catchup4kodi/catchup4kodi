addon_id="script.icechannel.dialogs"
addon_name="DUCKPOOL Custom Windows and Dialogs"
