addon_id="script.icechannel.theme.default"
addon_name="DUCKPOOL Theme"
