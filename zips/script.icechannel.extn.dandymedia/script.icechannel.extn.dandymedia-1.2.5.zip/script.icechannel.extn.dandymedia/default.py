addon_id="script.icechannel.extn.mucky_duck"
addon_name="Mucky Ducks iStream Extension"
