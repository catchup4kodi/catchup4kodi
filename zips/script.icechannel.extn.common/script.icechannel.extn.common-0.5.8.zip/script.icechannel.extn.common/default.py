addon_id="script.icechannel.extn.common"
addon_name=".DUCKPOOL - Common"
